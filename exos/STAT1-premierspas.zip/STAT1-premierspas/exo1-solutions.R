# STAT1 : Variable"
# Exercice n°1 : Premiers pas dans R
# Claude GRASLAND & Jean-Paul N’GBESSO
# 2025-04-27

# (A) CALCULS

# calculer 8 plus 2
8+2

# calculer 8 moins 2
8-2

# calculer 8 multiplié par 2
8*2

# calculer 8 divisé par 2
8/2

# Calculer 8 à la puissance 2 
8**2

# Calculer racine carrée de 8
8**(1/2)
sqrt(8)

# calculer le logarithme népérien de 10 
log(10)

# calculer le logarithme décimal de 10
log10(10)

# afficher le nombre pi
pi

# calculer le sinus de pi
sin(pi)

# calculer le cosinus de pi
cos(pi)

# calculer la tangente de pi
tan(pi)


# (B) TYPES ELEMENTAIRES

# TYPE NUMERIC
# stocker les valeurs x = 8 et y = 2
x<-8
y<-2

# calculer x+y
x+y

# calculer x-y
x*y

# calculer x puissance y
x**y

# calculer y puissance x
y**x


# TYPE CHARACTER

# Stocker x = "Bonjour" et y = "tout le monde"
x<-"Bonjour"
y<- "tout le monde"

# créer z = "Bonjour tout le monde"
z <-paste(x,y)

# Afficher z
z


# TYPE LOGIC
# créer x = vrai et y = faux
x <- TRUE
y <- FALSE

# calculer x et y
x & y

# calculer x ou y 
x | y 


# (C) VECTEURS

# Construire un vecteur x composé de 1,2,4,8,16 
x <- c(1,2,4,8,16)

# Construire une valeur y = 4
y <- 4

# Aditionner x et y
x+y

# Multiplier x et y
x*y

# Calculer x puissance y
x**y


# (D) MATRICES

# Soit les deux vecteurs x1 et x2
x1 <- c(1,2,4,8,16)
x2 <- c(5,10,15,20,25)

# construire une matrice m1 en colonnes
m1 <- cbind(x1,x2)
m1

# construire une matrice m2 en lignes
m2 <- rbind(x1,x2)
m2

# construire un grand vecteuur x3 composé de x1 et x2
x3 <- c(x1,x2)
x3
is.matrix(x3)




# (E) listes et vecteurs 

# Format vecteur
prenom <- c("Ali", "Amine",
    "Anne","Marc","Zayneb")
sexe <- c("H","H","F","H","F")
age  <- c(21,22,24,18,25)


# Format liste
Ali <- list("H",21)
Amine <- list("F",22)
Anne <- list("F",28)
Marc <- list ("H",18)
Zayneb <- list("F",25)

# Ne pas confondre !
Ali <- c("H",21)
Ali
Ali <- list("H",21)
Ali


# (F) CREATION D'UN DATA.FRAME
# Choisir 5 stagiaires pour faire le tableau

# variable de type character
prenom <- c("Ali", "Amine","Anne",
            "Marc","Zayneb")
str(prenom)

# variable de type logique
likeR <- c(TRUE,FALSE, TRUE,
           FALSE, FALSE)
str(likeR)

# variable de type factor
sexe <- c(1,1,2,1,2)
sexe<-as.factor(sexe)
levels(sexe) <-c("Homme","Femme")
str(sexe)

# variable de type numeric
age  <- c(21,22,24,18,25)
str(age)

# variable de type Date
nais<-c("1999-10-28","1998-10-13",
 "1996-10-15","2002-02-07","1995-06-18")
nais<-as.Date(nais)
str(nais)

# Création d'un data.frame
tab1<-data.frame(prenom,nais,
                age,sexe,likeR)
str(tab1)

# Résumé du tableau
summary(tab1)

