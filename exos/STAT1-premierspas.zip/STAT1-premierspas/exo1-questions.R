# STAT1 : Variable"
# Exercice n°1 : Premiers pas dans R
# Claude GRASLAND & Jean-Paul N’GBESSO
# 2025-04-27


# (A) CALCULS

# calculer 8 plus 2


# calculer 8 moins 2


# calculer 8 multiplié par 2


# calculer 8 divisé par 2


# Calculer 8 à la puissance 2 


# Calculer racine carrée de 8


# calculer le logarithme népérien de 10 


# calculer le logarithme décimal de 10


# afficher le nombre pi


# calculer le sinus de pi


# calculer le cosinus de pi


# calculer la tangente de pi



# (B) TYPES ELEMENTAIRES

# TYPE NUMERIC
# stocker les valeurs x = 8 et y = 2


# calculer x+y


# calculer x-y


# calculer x puissance y


# calculer y puissance x



# TYPE CHARACTER

# Stocker x = "Bonjour" et y = "tout le monde"


# créer z = "Bonjour tout le monde"


# Afficher z



# TYPE LOGIC
# créer x = vrai et y = faux


# calculer x et y


# calculer x ou y 



# (C) VECTEURS

# Construire un vecteur x composé de 1,2,4,8,16 


# Construire une valeur élémentaire y = 4


# Aditionner x et y


# Multiplier x et y


# Calculer x puissance y



# (D) MATRICES

# Soit les deux vecteurs x1 et x2
x1 <- c(1,2,4,8,16)
x2 <- c(5,10,15,20,25)

# construire une matrice m1 avec x1 et x2 en colonnes


# construire une matrice m2 avec x1 et x2 en lignes


# construire un grand vecteuur x3 composé de x1 et x2





# (E) listes et vecteurs 

# Format vecteur
prenom <- c("Ali", "Amine",
    "Anne","Marc","Zayneb")
sexe <- c("H","H","F","H","F")
age  <- c(21,22,24,18,25)


# Format liste
Ali <- list("H",21)
Amine <- list("F",22)
Anne <- list("F",28)
Marc <- list ("H",18)
Zayneb <- list("F",25)

# Ne pas confondre !
Ali <- c("H",21)
Ali
Ali <- list("H",21)
Ali


# (F) CREATION D'UN DATA.FRAME
# Choisir 5 stagiaires pour faire le tableau

# enregistrer les prénoms
prenom <- 
          
str(prenom)

# enregistrer l'intérêt pour R
likeR <- 
  
str(likeR)

# enregistrer le sexe sous la forme 1 ou 2 
# puis convertir en "homme" ou "femme"
sexe <- 
sexe<-as.factor(sexe)
levels(sexe) <-
str(sexe)

# enregister l'âge en années
age  <- 
str(age)

# enregistrer la date de naissance
nais<-
nais<-as.Date(nais)
str(nais)



# Créer un data.frame
tab1<-
  
str(tab1)

# Résumer le tableau

