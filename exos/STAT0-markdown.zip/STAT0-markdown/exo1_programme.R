### Programme R d'analyse des inégalités régionales
### Auteurs : Claude et Jean-Paul 
### Date : Juillet 2025, AfroMapR
### Source des données : Global Data Lab


############# ETAPE1 : préparation des données ############

### 1.1 Importation du tableau
don <- read.table(file = "africa_idh_1992_2022/data/don_reg.csv",
                  header= TRUE,
                  dec=".",
                  sep =";")

### 1.2 Sélection du pays
### On peut changer le pays en remplaçant CIV 
### par NGA, SEN ...

sel <- don[don$iso_code=="CIV",]


### 1.3 Sélection des variables
### On peut changer les dates en remplaçant 2022 
### par 2012, 2002 ou 1992

sel <-sel[, c("gdlcode",
              "region",
              "sup",
              "pop_2022",
              "pib_hab_2022",
              "esp_vie_2022")]

### 1.4 Recodage des noms de variables

names(sel) <-c("code","nom","sup","pop","pib","esp")

### (1.5) Transformation de variables

sel$pop <- sel$pop*1000
sel$den <- round(sel$pop/sel$sup)

### 1.6 Affichage du tableau
### Vérifier que le tableau est correct avant
### de passer à la suite.

sel

############## ETAPE 2 : Population, superficie et densité  du pays #################

poptot<-sum(sel$pop)
paste("Population = ", poptot, "habitants")

suptot <- sum(sel$sup)
paste( "Superficie = ", suptot, "km2")

dentot <- round(poptot/suptot)
paste("Densité = ", dentot, "hab./km2")


################ ETAPE 3 : Paramètres principaux #############
 
summary(sel)


################## ETAPE 4 : Analyse du PIB par habitant ########

### 4.1 Paramètres principaux

summary(sel$pib)



### 4.2 Histogramme

hist(sel$pib,
     breaks=quantile(sel$pib) ,
     main= "Histogramme",
     xlab = "PIB en $/hab",
     col="lightyellow")

### 4.3 Boxplot

boxplot(sel$pib,
        horizontal = TRUE,
        main= "Boîte à moustache",
        xlab = "PIB en $/hab",
        col="lightyellow")

##################### ETAPE 5 :Analyse de l'espérance de vie ###########

### 5.1 Paramètres principaux

summary(sel$esp)

### 5.2 Histogramme 

hist(sel$esp,
     breaks=quantile(sel$esp) ,
     main= "histogramme",
     xlab = "Espérance de vie en année",
     col="lightyellow")


### 5.3 Boxplot

boxplot(sel$esp,
        horizontal = TRUE,
        main= "boîte à moustache",
        xlab = "Espérance de vie en année",
        col="lightyellow")

################## ETAPE 6 : Relation entre X et Y  ##########


### 6.1 Diagramme de relation

plot(sel$pib,sel$esp,
     xlab = "X : PIB par habitant",
     ylab = "Y : Espérance de vie",
     main = "Relation entre X et Y",
     pch=20,
     col="red")
text(sel$pib,sel$esp,sel$nom,
     cex=0.4,
     col="blue",
     pos=1)
grid()

### 6.2 Corrélation et test

cor.test(sel$pib,sel$esp)


############ ETAPE 7 : Régression linéaire Y=a.X+b ######


### 7.1 Calcul de l'équation

modreg<-lm(esp~pib,data=sel)
summary(modreg)

### 7.2 Tracé de la droite de régression

plot(sel$pib,sel$esp,
     xlab = "X : PIB par habitant",
     ylab = "Y : Espérance de vie",
     main = "Droite de régression Y=aX+b",
     pch=20,
     col="red")
text(sel$pib,sel$esp,sel$nom,
     cex=0.4,
     col="blue",
     pos=1)
grid()
abline(modreg, col="black",lwd=2)




